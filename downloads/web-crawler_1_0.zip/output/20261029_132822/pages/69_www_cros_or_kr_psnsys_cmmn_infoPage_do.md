# 통합생체(FIDO)인증사용 안내 < 사용자인증서비스 < 고객센터 < 홈

- URL: https://www.cros.or.kr/psnsys/cmmn/infoPage.do?w2xPath=/ui/twc/reginf/auth/fidoMan.xml.xml
- 수집 시각: 2026-10-29T13:27:54

