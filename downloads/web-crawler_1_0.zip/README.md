# 웹 크롤러 (Playwright + LangChain)

웹 페이지를 브라우저로 열어 본문을 수집하고, Claude Pro 채팅에 바로 올려 분석할 수 있는 파일로 만들어 줍니다.

## 1. 설치 (처음 한 번)

Python 3.10 이상이 필요합니다.

```bash
cd web-crawler
python -m venv .venv
# Windows: .venv\Scripts\activate    macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
playwright install chromium
```

## 2-A. 웹 화면으로 쓰기 (명령어 없이)

명령어 대신 브라우저 화면으로 쓰고 싶으면 아래를 실행하세요. **추가 설치가 필요 없습니다**(파이썬 표준 기능만 사용).

```bash
python webapp.py --open      # 브라우저가 자동으로 http://127.0.0.1:8777 을 엽니다
```

화면에서 시작 URL·깊이·로그인 정보를 넣고 **[수집 시작]**을 누르면, 진행 로그가 실시간으로 보이고
끝나면 `burp_history.xml` 등 결과 파일을 바로 내려받을 수 있습니다. **모든 처리는 이 PC 안에서만** 이뤄지며,
자격 증명이나 수집 데이터는 외부로 전송되지 않습니다.

- **수동 로그인**: 체크하면 브라우저 창이 떠서 직접 로그인할 수 있고, 로그인 후 화면의 **[로그인 완료]** 버튼을 누르면 수집이 이어집니다(캡차·OTP·SSO용).
- 내려받은 `burp_history.xml`을 **민감정보 탐지기**에 올리면 응답값 점검까지 이어집니다.
- **여러 번 쓰기**: 수집 결과는 탐지기에 *추가*로 쌓이고(같은 URL·같은 응답은 중복 제외), 탐지기에서는 **파일 단위**로 삭제할 수 있습니다.
- **초기화**: **[입력 초기화]** = 입력란만 기본값으로. **[결과 지우기]** = 화면 로그·진행도·결과 목록 + `output/날짜_시간` 폴더 + 탐지기 데이터 삭제.
  **[전체 초기화]** = 위 + 입력란까지. 로그인 세션 파일(`output/*.json`)은 체크했을 때만 지우며, 수집 중에는 지워지지 않습니다.

> 아래 2~5번은 같은 기능을 터미널 명령어로 쓰는 방법입니다. 둘 중 편한 쪽을 쓰면 됩니다.

## 2. 수집하기 (무료, API 키 불필요)

```bash
# 주소 직접 입력
python crawler.py https://example.com https://example.org

# urls.txt 목록으로 수집
python crawler.py -f urls.txt

# 스크롤해야 내용이 더 나오는 페이지
python crawler.py -f urls.txt --scroll 5

# 특정 요소가 뜰 때까지 기다리기 / 브라우저 창 보면서 실행
python crawler.py https://example.com --wait-for ".product-list" --show
```

### 하위 페이지까지 수집하기

기본은 적어준 주소만 수집합니다. 페이지 안의 링크를 따라가며 하위 페이지까지 모으려면 `--depth`를 씁니다.

```bash
# 시작 주소에서 2단계까지, 최대 50페이지 (같은 호스트만)
python crawler.py https://example.com --depth 2 --max-pages 50

# www·blog 등 같은 상위도메인의 서브도메인도 함께
python crawler.py https://example.com --depth 2 --allow-subdomains
```

- `--depth N` : `0`=시작 주소만, `1`=직접 링크까지, `2`=두 단계까지…
- `--max-pages N` : 전체 수집 상한 (기본 50). 사이트가 커도 여기서 멈춥니다.
- 기본적으로 **같은 호스트**만 따라가고, 외부 사이트와 이미지·스크립트 등 자원 링크는 제외합니다.
- 순환 링크는 자동으로 중복 제거되며, robots.txt는 그대로 지킵니다.
- 서버 부담을 줄이려면 `--delay 2` 처럼 요청 간격을 늘리세요.

결과는 `output/날짜_시간/` 폴더에 생깁니다.

| 파일 | 내용 |
|---|---|
| `for_claude.md` | 모든 페이지를 합친 파일. **Claude에 올려서 분석** |
| `burp_history.xml` | **요청·응답 원문**(XHR·fetch·문서 포함). **민감정보 탐지기**와 Burp 사이트맵 트리에 그대로 올리기 |
| `sitemap.xml` | **Burp 사이트맵 트리 아티팩트**에 넣어 구조 분석 (응답코드 포함) |
| `sitemap_urls.txt` | URL 목록. 트리 아티팩트에 붙여넣거나 Burp로 가져오기 |
| `pages/*.md` | 페이지별 본문 |
| `results.json` | 전체 데이터 (다른 프로그램에서 쓰기 좋음) |

### 응답 원문까지 수집하기 (Burp 형식)

기본으로 페이지가 주고받는 **XHR·fetch·문서 응답의 원문**을 `burp_history.xml`에 저장합니다.
화면에 보이는 본문만이 아니라, 자바스크립트가 뒤에서 불러오는 JSON·`.do` 응답까지 담깁니다.
이 파일은 **민감정보 탐지기** 아티팩트에 그대로 올려 응답값 속 주민번호·카드·계정 등을 검사할 수 있습니다.

```bash
python crawler.py https://example.com --depth 2 --max-pages 100   # 캡처는 기본 켜짐
python crawler.py https://example.com --no-capture                # 화면 본문만, 원문 저장 안 함
```

### 로그인 후 페이지 수집하기

> 반드시 **점검 권한이 있는 대상**에만 사용하세요.

```bash
# 자동 로그인: ID/PW 입력란을 찾아 채우고 로그인
python crawler.py https://site/main --login-url https://site/login \
  --username myid --password 'mypw' --depth 2 --max-pages 100

# 입력란 자동 탐지가 실패하면 CSS 선택자를 직접 지정
python crawler.py https://site/main --login-url https://site/login \
  --username myid --password 'mypw' \
  --username-selector "#userId" --password-selector "#userPw" --submit-selector ".btn-login"

# 수동 로그인: 창에서 직접 로그인(캡차·OTP·SSO). Enter를 누르면 수집 시작
python crawler.py https://site/main --login-url https://site/login --manual-login

# 세션 저장 후 재사용 (다음 실행부터 로그인 생략)
python crawler.py https://site/login --username myid --password 'mypw' --session session.json
python crawler.py https://site/main --depth 2 --session session.json
```

- `--password` 값은 `burp_history.xml` 원문에서 자동으로 `***REDACTED***`로 가립니다.
- 로그아웃 링크(`logout`, `signout` 등)는 세션이 풀리지 않도록 **자동으로 제외**합니다. 패턴은 `--logout-pattern`으로 조정합니다.
- `--manual-login`을 쓰면 브라우저 창이 자동으로 뜹니다(`--show` 포함).

### Burp 사이트맵 트리로 구조 보기

수집한 사이트의 경로 구조(디렉터리·페이지·파라미터)를 트리로 보려면,
생성된 `sitemap.xml`을 **「Burp 사이트맵 트리」 아티팩트**에 끌어다 놓거나 파일 선택으로 불러오세요.
유형별 색상, 관리·인증·파일 태그, 쿼리 변형, 응답코드 필터가 그대로 적용됩니다.
`sitemap_urls.txt`는 URL만 필요한 경우(붙여넣기)에 쓰면 됩니다.

## 3. Claude Pro로 분석하기

1. claude.ai(또는 Claude 앱)에서 새 채팅을 엽니다.
2. `for_claude.md` 파일을 첨부합니다.
3. 원하는 분석을 요청합니다. 예:
   - "각 페이지 핵심을 3줄로 요약하고 공통점을 정리해줘"
   - "상품 이름, 가격, 특징을 표로 만들어줘"

> Claude Pro 구독에는 API 사용이 포함되지 않습니다. 이 방식은 API 키 없이 Pro 구독 범위 안에서 분석합니다.
> 페이지가 너무 많아 파일이 크면 `--max-chars 8000`처럼 페이지당 글자 수를 줄이세요.

## 4. (선택) LLM 자동 추출

수집하면서 바로 항목을 뽑고 싶을 때 사용합니다.

**Claude API** — console.anthropic.com에서 API 키 발급 (Pro와 별도 과금)

```bash
pip install langchain-anthropic
cp .env.example .env      # .env에 ANTHROPIC_API_KEY 입력
python crawler.py -f urls.txt --llm claude --fields "상품명,가격,할인율"
```

**Ollama (로컬, 무료)** — ollama.com에서 설치 후

```bash
ollama pull qwen2.5:7b
pip install langchain-ollama
python crawler.py -f urls.txt --llm ollama --instruction "채용 공고의 회사명, 직무, 연봉만 뽑아줘"
```

추출 결과는 `results.json`의 `extracted` 항목과 `for_claude.md`에 함께 들어갑니다.

## 전체 옵션

```bash
python crawler.py --help
```

## 주의

- 기본적으로 robots.txt에서 금지한 페이지는 건너뜁니다.
- 수집 전 사이트 이용약관을 확인하고, `--delay`로 요청 간격을 두세요.
- 로그인이 필요한 페이지나 개인정보는 수집하지 마세요.
